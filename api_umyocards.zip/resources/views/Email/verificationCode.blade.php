<h3>Dear {{ $username }}, </h3>
<p>You account verification code is {{ $verification_code }}</p>