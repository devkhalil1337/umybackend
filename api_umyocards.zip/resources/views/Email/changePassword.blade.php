<h3>Dear {{ $username }}, </h3>
<p>You can now login to your account with password ({{$password}}) and can reset your password.</p>