<h3>Dear <?php echo e($name); ?>, </h3>

<?php if($chats): ?>
<h3>Below is your chat.</h3>

<?php $__currentLoopData = $chats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<p><?php echo e($chat->user_message); ?></p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php endif; ?><?php /**PATH /home/umyocard/public_html/nubianbizcards/api_umyocards/resources/views/Email/sendChat.blade.php ENDPATH**/ ?>